/**
 * Copyright JS Foundation and other contributors, http://js.foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **/
RED.editor.types._buffer = (function() {


    var template = '<script type="text/x-red" data-template-name="_buffer"><div id="node-input-buffer-panels"><div id="node-input-buffer-panel-str" class="red-ui-panel"><div class="form-row" style="margin-bottom: 3px; text-align: right;"><span class="node-input-buffer-type"><i class="fa fa-exclamation-circle"></i> <span id="node-input-buffer-type-string" data-i18n="bufferEditor.modeString"></span><span id="node-input-buffer-type-array" data-i18n="bufferEditor.modeArray"></span></span></div><div class="form-row node-text-editor-row"><div class="node-text-editor" id="node-input-buffer-str"></div></div></div><div id="node-input-buffer-panel-bin" class="red-ui-panel"><div class="form-row node-text-editor-row" style="margin-top: 10px"><div class="node-text-editor" id="node-input-buffer-bin"></div></div></div></div></script>';

    function stringToUTF8Array(str) {
        var data = [];
        var i=0, l = str.length;
        for (i=0; i<l; i++) {
            var char = str.charCodeAt(i);
            if (char < 0x80) {
                data.push(char);
            } else if (char < 0x800) {
                data.push(0xc0 | (char >> 6));
                data.push(0x80 | (char & 0x3f));
            } else if (char < 0xd800 || char >= 0xe000) {
                data.push(0xe0 | (char >> 12));
                data.push(0x80 | ((char>>6) & 0x3f));
                data.push(0x80 | (char & 0x3f));
            } else {
                i++;
                char = 0x10000 + (((char & 0x3ff)<<10) | (str.charAt(i) & 0x3ff));
                data.push(0xf0 | (char >>18));
                data.push(0x80 | ((char>>12) & 0x3f));
                data.push(0x80 | ((char>>6) & 0x3f));
                data.push(0x80 | (char & 0x3f));
            }
        }
        return data;
    }


    return {
        init: function() {
            $(template).appendTo(document.body);
        },
        show: function(options) {
            var value = options.value;
            var onComplete = options.complete;
            var type = "_buffer"
            RED.view.state(RED.state.EDITING);
            var bufferStringEditor = [];
            var bufferBinValue;

            var panels;

            var trayOptions = {
                title: options.title,
                width: "inherit",
                buttons: [
                    {
                        id: "node-dialog-cancel",
                        text: RED._("common.label.cancel"),
                        click: function() {
                            RED.tray.close();
                        }
                    },
                    {
                        id: "node-dialog-ok",
                        text: RED._("common.label.done"),
                        class: "primary",
                        click: function() {
                            onComplete(JSON.stringify(bufferBinValue));
                            RED.tray.close();
                        }
                    }
                ],
                resize: function(dimensions) {
                    var height = $("#dialog-form").height();
                    if (panels) {
                        panels.resize(height);
                    }
                },
                open: function(tray) {
                    var trayBody = tray.find('.editor-tray-body');
                    var dialogForm = RED.editor.buildEditForm(tray.find('.editor-tray-body'),'dialog-form',type,'editor');

                    bufferStringEditor = RED.editor.createEditor({
                        id: 'node-input-buffer-str',
                        value: "",
                        mode:"ace/mode/text"
                    });
                    bufferStringEditor.getSession().setValue(value||"",-1);

                    bufferBinEditor = RED.editor.createEditor({
                        id: 'node-input-buffer-bin',
                        value: "",
                        mode:"ace/mode/text",
                        readOnly: true
                    });

                    var changeTimer;
                    var buildBuffer = function(data) {
                        var valid = true;
                        var isString = typeof data === 'string';
                        var binBuffer = [];
                        if (isString) {
                            bufferBinValue = stringToUTF8Array(data);
                        } else {
                            bufferBinValue = data;
                        }
                        var i=0,l=bufferBinValue.length;
                        var c = 0;
                        for(i=0;i<l;i++) {
                            var d = parseInt(bufferBinValue[i]);
                            if (!isString && (isNaN(d) || d < 0 || d > 255)) {
                                valid = false;
                                break;
                            }
                            if (i>0) {
                                if (i%8 === 0) {
                                    if (i%16 === 0) {
                                        binBuffer.push("\n");
                                    } else {
                                        binBuffer.push("  ");
                                    }
                                } else {
                                    binBuffer.push(" ");
                                }
                            }
                            binBuffer.push((d<16?"0":"")+d.toString(16).toUpperCase());
                        }
                        if (valid) {
                            $("#node-input-buffer-type-string").toggle(isString);
                            $("#node-input-buffer-type-array").toggle(!isString);
                            bufferBinEditor.setValue(binBuffer.join(""),1);
                        }
                        return valid;
                    }
                    var bufferStringUpdate = function() {
                        var value = bufferStringEditor.getValue();
                        var isValidArray = false;
                        if (/^[\s]*\[[\s\S]*\][\s]*$/.test(value)) {
                            isValidArray = true;
                            try {
                                var data = JSON.parse(value);
                                isValidArray = buildBuffer(data);
                            } catch(err) {
                                isValidArray = false;
                            }
                        }
                        if (!isValidArray) {
                            buildBuffer(value);
                        }

                    }
                    bufferStringEditor.getSession().on('change', function() {
                        clearTimeout(changeTimer);
                        changeTimer = setTimeout(bufferStringUpdate,200);
                    });

                    bufferStringUpdate();

                    dialogForm.i18n();

                    panels = RED.panels.create({
                        id:"node-input-buffer-panels",
                        resize: function(p1Height,p2Height) {
                            var p1 = $("#node-input-buffer-panel-str");
                            p1Height -= $(p1.children()[0]).outerHeight(true);
                            var editorRow = $(p1.children()[1]);
                            p1Height -= (parseInt(editorRow.css("marginTop"))+parseInt(editorRow.css("marginBottom")));
                            $("#node-input-buffer-str").css("height",(p1Height-5)+"px");
                            bufferStringEditor.resize();

                            var p2 = $("#node-input-buffer-panel-bin");
                            editorRow = $(p2.children()[0]);
                            p2Height -= (parseInt(editorRow.css("marginTop"))+parseInt(editorRow.css("marginBottom")));
                            $("#node-input-buffer-bin").css("height",(p2Height-5)+"px");
                            bufferBinEditor.resize();
                        }
                    });

                    $(".node-input-buffer-type").click(function(e) {
                        e.preventDefault();
                        RED.sidebar.info.set(RED._("bufferEditor.modeDesc"));
                        RED.sidebar.info.show();
                    })


                },
                close: function() {
                    if (options.onclose) {
                        options.onclose();
                    }
                    bufferStringEditor.destroy();
                    bufferBinEditor.destroy();
                },
                show: function() {}
            }
            RED.tray.show(trayOptions);
        }
    }
})();
