# Watson Deprecated Services

The following Watson services have been deprecated. The labs are still available to demonstrate the techniques used:
- [Alchemy Feature Extraction](alchemy_api_feature_extraction/README.md)
- [Alchemy Vision](alchemy_api_image_analysis/README.md)
- [Alchemy News](alchemy_data_news/README.md)
- [Concept Insights](concept_insights/README.md)
- [Dialog](dialog/README.md)
- [Dialog Template Creation](dialog_template_creation/README.md)
- [Document Conversion](document_conversion/README.md)
- [Relationship Extraction](relationship_extraction/README.md)
- [Retrieve and Rank](retrieve_and_rank/README.md)
- [Tradeoff Analytics](tradeoff_analytics/README.md)
