// Placeholder only - This is NOT a sustainable solution to i18n localisation
// Replace/overwrite this file with an angular-locale_... file of your choice from the npm angular-i18n project
// Then edit dashboard.appcache - (for example add a digit to the hash)
// Stop, start Node-RED and refresh the browser page twice to flush the cache.
