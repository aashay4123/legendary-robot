---
layout: blog
title: Internet of Things Messaging Hangout
author: nick
---

I was asked to join some of my Messaging colleagues in a Google Handout earlier today to talk about the Internet of Things, Node-RED and the upcoming [ThingMonk conference](http://redmonk.com/thingmonk/).

It's a brief introduction to what Node-RED is about, why we used node.js and what we've planned for the future.

If you want to hear more about the developer experience of IoT, coming along to [ThingMonk](http://redmonk.com/thingmonk/tickets/).

<div class="video-container"><iframe width="640" height="360" src="//www.youtube.com/embed/OrgxLl9AaHI" frameborder="0" allowfullscreen></iframe></div>
