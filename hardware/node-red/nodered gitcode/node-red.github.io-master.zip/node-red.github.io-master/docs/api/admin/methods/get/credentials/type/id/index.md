---
layout: docs
toc: api-toc.html
title: GET /credentials/:type/:id
---

