---
layout: docs
toc: api-toc.html
title: Runtime API
---

This API can be used when embedding Node-RED into another application.

### Getting Started

Node-RED can be loaded into another node.js application using the standard
`require` module loader.
