---
layout: docs
toc: developing-toc.html
title: Developing Node-RED
---

Eventually, we will have some good documentation on the internals of Node-RED to
make it easier for anyone to get involved with its development.

In the meantime:

 - Here are our [Contribution Guidelines](/about/contribute/)
 - Various design notes are on the [wiki](https://github.com/node-red/node-red/wiki)

If this is an area you are interested in, come talk to us on the [mailing list](https://groups.google.com/forum/#!forum/node-red)
or [Slack team](http://nodered.org/slack/).
