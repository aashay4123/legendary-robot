import * as winston from 'winston';
import 'winston-daily-rotate-file';
import * as moment from 'moment';

const transport = new winston.transports.DailyRotateFile({
  filename: 'log',
  datePattern: 'yyyy-MM-dd.',
  prepend: true,
  timestamp: function() {
    return moment().format('DD/MM/YYYY HH:mm:SS');
  },
  level: process.env.LOG_LEVEL || 'debug'
});

export const LOGGER = new winston.Logger({
  transports: [
    new winston.transports.Console({
      timestamp: function() {
        return moment().format('DD/MM/YYYY HH:mm:SS');
      },
      formatter: function(options) {
        return (
          options.timestamp() +
          ' ' +
          options.level.toUpperCase() +
          ' ' +
          (options.message ? options.message : '') +
          (options.meta && Object.keys(options.meta).length
            ? '\n\t' + JSON.stringify(options.meta)
            : '')
        );
      }
    }),
    transport
  ]
});

LOGGER.level = process.env.LOG_LEVEL || 'debug';
