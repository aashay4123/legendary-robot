import * as express from 'express';
import { Express, Request, Response } from 'express';
import * as bodyParser from 'body-parser';
import * as http from 'http';
import { LOGGER } from './config/logger';
import { config } from 'dotenv';
import { graphqlExpress, graphiqlExpress } from 'apollo-server-express';
import schema from './schemas';

//NODE-RED
const RED = require('node-red');
const cors = require('cors');
const mosca = require('mosca');

const RED_SETINGS = {
  httpAdminRoot: '/red',
  httpNodeRoot: '/',
  userDir: './.nodered/',
  nodesDir: './.nodered/nodes',
  flowFile: 'flows.json',
  flowFilePretty: true,
  functionGlobalContext: {} // enables global context
};

config();

const app = express();

app.use(cors());

const server = http.createServer(app);

RED.init(server, RED_SETINGS);
app.use(RED_SETINGS.httpAdminRoot, RED.httpAdmin);
app.use(RED_SETINGS.httpNodeRoot, RED.httpNode);

RED.start();
server.listen(process.env.PORT, () => {
  LOGGER.info(`App Api listening on port ${process.env.PORT}!`);
});

//Mosca MQTT server
const MOSCA_SETTINGS = {
  port: parseInt(process.env.MOSCA_PORT, 10),
  backend: {
    type: 'mongo',
    url: process.env.MONGO_URL,
    pubsubCollection: 'mqtt',
    mongo: {}
  }
};

const mqtt = new mosca.Server(MOSCA_SETTINGS);

mqtt.on('ready', () =>
  LOGGER.info(`MQTT Broker listening on port ${process.env.MOSCA_PORT}!`)
);

// Graphql endpoint
app.use('/graphql', bodyParser.json(), graphqlExpress({ schema }));

app.use(
  '/graphiql',
  graphiqlExpress({
    endpointURL: '/graphql'
  })
);
