import { filter, some } from 'lodash';

export const Comment = `
  type Comment {
    id: Int!
    message: String
    author: String
  }

  extend type Query {
    comments(id: [Int]): [Comment]
  }
`;

const comments = [
  { id: 1, message: 'Comment 1' },
  { id: 2, message: 'Comment 2' },
  { id: 3, message: 'Comment 3' },
  { id: 4, message: 'Comment 4' }
];

export const CommentResolvers = {
  comments: (ids: number[]) => filter(comments, c => some(ids, c.id))
};

export const CommentMutations = {};
