import { LOGGER } from './../config/logger';
import { makeExecutableSchema } from 'graphql-tools';
import { Post, PostResolvers, PostMutations } from './post';
import { Comment, CommentResolvers, CommentMutations } from './comment';

const resolvers = {
  Query: {
    ...PostResolvers,
    ...CommentResolvers
  },
  Mutation: {
    ...PostMutations,
    ...CommentMutations
  }
};

const SchemaDefinition = `
type Query {
  user(id: Int): String
}

type Mutation {
  user(id: Int): String
}

schema {
  query: Query
  mutation: Mutation
}
`;

export default makeExecutableSchema({
  typeDefs: [SchemaDefinition, Post, Comment],
  resolvers,
  logger: {
    log: (message: string) => LOGGER.debug(message)
  }
});
