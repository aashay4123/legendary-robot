const tslint = require('gulp-tslint');
const gulp = require('gulp');
const ts = require('gulp-typescript');
const clean = require('gulp-clean');
const debug = require('gulp-debug');
const sourcemaps = require('gulp-sourcemaps');
const tsProject = ts.createProject('tsconfig.json');
const nodemon = require('gulp-nodemon');
const runSequence = require('run-sequence');

const SRC_DIR = 'src/';

const tslintOptions = {
  formatter: 'stylish'
};
const reportOptions = {
  emitError: true
};
gulp.task('clean', _ => gulp.src('dist').pipe(clean()));

gulp.task('tslint', _ =>
  gulp
    .src(`${SRC_DIR}/**/*.ts`, { base: '.' })
    .pipe(tslint(tslintOptions))
    .pipe(tslint.report(reportOptions))
);

gulp.task('nodered', _ =>
  gulp.src('.nodered/flows.json').pipe(gulp.dest('dist/.nodered'))
);

gulp.task('.env', _ => gulp.src(`.env`).pipe(gulp.dest('dist')));

gulp.task('build:dev', _ =>
  tsProject
    .src()
    .pipe(sourcemaps.init())
    .pipe(tsProject(ts.reporter.fullReporter()))
    .pipe(
      sourcemaps.write('.', {
        sourceRoot: file => {
          return file.cwd + SRC_DIR;
        }
      })
    )
    .pipe(gulp.dest('dist'))
);

gulp.task('copy:package', _ =>
  gulp.src('package.json').pipe(gulp.dest('dist'))
);

gulp.task('build:release', _ =>
  tsProject
    .src()
    .pipe(tsProject(ts.reporter.fullReporter()))
    .pipe(gulp.dest('dist'))
);

gulp.task('livereload', _ =>
  nodemon({
    script: 'dist/index.js',
    ext: 'ts json',
    watch: SRC_DIR,
    tasks: ['build:dev']
  })
);

gulp.task('build', _ =>
  runSequence('clean', 'tslint', 'nodered', '.env', 'build:dev', _)
);

gulp.task('release', _ =>
  runSequence('clean', 'tslint', 'nodered', 'copy:package', 'build:release', _)
);

gulp.task('default', _ =>
  runSequence(
    'clean',
    'tslint',
    'nodered',
    '.env',
    'build:dev',
    'livereload',
    _
  )
);
