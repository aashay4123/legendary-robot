node-red-node-feedparser
========================

A <a href="http://nodered.org" target="_new">Node-RED</a> node to read RSS and Atom feeds.

Install
-------

Run the following command in your Node-RED user directory - typically `~/.node-red`

        npm install node-red-node-feedparser

Usage
-----

### Input

Monitors an RSS/atom feed for new entries.

You can set the polling time in minutes. Defaults to 15 minutes.
