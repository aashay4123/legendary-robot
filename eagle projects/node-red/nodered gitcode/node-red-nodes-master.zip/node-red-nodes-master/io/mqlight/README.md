node-red-node-mqlight
======================

A [Node-RED](http://nodered.org) node to send/receive messages using [IBM MQ Light](https://developer.ibm.com/messaging/mq-light/).

Install
-------

Run the following command in your Node-RED user directory - typically `~/.node-red`

    npm install node-red-node-mqlight
