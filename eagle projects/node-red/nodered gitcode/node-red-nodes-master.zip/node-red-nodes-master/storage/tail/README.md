node-red-node-tail
==================

A Node-Red node to tail a file and inject the contents into the flow.

Install
-------

Either use the Menu - Manage palette option, or run the following command in your Node-RED user directory - typically `~/.node-red`

    npm install node-red-node-tail


Usage
-----

Allows 
